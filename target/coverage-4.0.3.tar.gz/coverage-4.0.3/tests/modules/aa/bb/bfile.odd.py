# bfile.odd.py
