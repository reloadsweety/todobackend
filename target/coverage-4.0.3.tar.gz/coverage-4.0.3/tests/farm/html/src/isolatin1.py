# -*- coding: iso8859-1 -*-
# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://bitbucket.org/ned/coveragepy/src/default/NOTICE.txt

# A Python source file in another encoding.

math = "3�4 = 12, �2 = 6�0"
assert len(math) == 18
