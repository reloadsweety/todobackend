"""django-nose management commands."""
